LORD BUDDHA FREE SCHOOL website for GitHub Pages

Upload index.html and the entire assets folder to the ROOT of your GitHub repository. Do not upload only index.html.

The gallery contains the photos from the ZIP you supplied. Keep assets/photos next to index.html inside the assets folder.

Before publishing identifiable photos of children publicly, make sure the school has appropriate parent/guardian consent.
